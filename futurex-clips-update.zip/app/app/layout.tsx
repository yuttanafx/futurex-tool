import Link from 'next/link'
import AppNav from '@/components/AppNav'
import { signOut } from '@/app/login/actions'
import { getContext } from '@/lib/tenant'
import MarketingBackground from '@/components/MarketingBackground'
import { Controls, T } from '@/components/Prefs'
import Copyright from '@/components/Copyright'
import BillingBanner from '@/components/BillingBanner'
import type { Tx } from '@/lib/i18n'
import { stopManage } from '@/app/admin/shops/actions'
export const dynamic = 'force-dynamic'
const tx = (th: string, en: string, zh: string): Tx => ({ th, en, zh })
const NAV: [Tx, [string, Tx][]][] = [
  [tx('ภาพรวม', 'Overview', '概览'), [['/app/dashboard', tx('แดชบอร์ด', 'Dashboard', '仪表盘')]]],
  [tx('ขาย', 'Sales', '销售'), [
    ['/app/products', tx('สินค้า', 'Products', '商品')], ['/app/pages', tx('เซลเพจ', 'Sales pages', '销售页')],
    ['/app/orders', tx('คำสั่งซื้อ', 'Orders', '订单')], ['/app/customers', tx('ลูกค้า', 'Customers', '客户')]]],
  [tx('AI และสื่อสาร', 'AI & Communication', 'AI 与沟通'), [
    ['/app/inbox', tx('กล่องข้อความ', 'Inbox', '收件箱')], ['/app/ai', tx('ผู้ช่วย AI', 'AI assistant', 'AI 助手')],
    ['/app/ai-keys', tx('ตั้งค่า API ของ AI', 'AI API keys', 'AI API 密钥')],
    ['/app/live', tx('ไลฟ์', 'Live', '直播')], ['/app/content', tx('คอนเทนต์', 'Content', '内容')],
    ['/app/adcontent', tx('ยิงแอด คอนเทนต์', 'Ad Content', '广告内容')],
    ['/app/tiktok', tx('ปักตะกร้า TikTok', 'TikTok Basket', 'TikTok 购物车')],
    ['/app/clips', tx('รวมคลิปตั้งเวลาโพส', 'Clips & Scheduled Posts', '视频合集·定时发布')],
    ['/app/mbo', tx('ล็อกอินสมาชิก FutureX', 'FutureX Member Login', 'FutureX 会员登录')]]],
  [tx('เครื่องมือ', 'Tools', '工具'), [
    ['/app/nfc', tx('NFC', 'NFC', 'NFC')], ['/app/referrals', tx('ลิงก์แนะนำ', 'Referrals', '推荐链接')],
    ['/app/billing', tx('ค่าบริการ & วอลเล็ต', 'Billing & Wallet', '费用与钱包')],
    ['/app/integrations', tx('ช่องทาง', 'Channels', '渠道')], ['/app/settings', tx('ตั้งค่า', 'Settings', '设置')]]],
]
export default async function WorkspaceLayout({ children }: { children: React.ReactNode }) {
  const { tenant, user, sb, impersonating } = await getContext()
  const [{ data: isAdmin }, { data: tp }] = await Promise.all([sb.rpc('is_platform_admin'), sb.from('tenants').select('plan_id').eq('id', tenant.id).maybeSingle()])
  return (
    <div className="dk"><MarketingBackground />
      {impersonating && (
        <div className="sticky top-0 z-50 flex flex-wrap items-center justify-center gap-3 bg-yellow-400 px-4 py-2 text-sm font-medium text-black">
          <span><T th={`กำลังจัดการร้าน “${tenant.name}” แทนสมาชิก (แอดมิน)`} en={`Managing “${tenant.name}” on behalf of the member (admin)`} zh={`正在代会员管理「${tenant.name}」（管理员）`} /></span>
          <form action={stopManage}><button className="rounded bg-black px-3 py-1 text-white"><T th="ออกจากร้านนี้" en="Exit this shop" zh="退出此店铺" /></button></form>
        </div>
      )}<div className="mx-auto flex max-w-6xl flex-col gap-6 px-6 py-8 md:flex-row">
      <aside className="md:w-56 md:shrink-0">
        <Controls className="mb-4 flex-wrap" />
        <div className="card">
          <p className="text-xs text-ink/60">WORKSPACE</p>
          <strong className="block truncate">{tenant.name}</strong>
          <Link href={`/s/${tenant.slug}`} target="_blank" className="mt-2 block text-sm text-brand underline"><T th="ดูหน้าร้านของฉัน" en="View my shop" zh="查看我的店铺" /></Link>
        </div>
        <AppNav groups={NAV} />
        <div className="mt-6 border-t border-ink/10 pt-4">
          {isAdmin === true && <Link href="/admin" className="navbtn mb-2"><span className="ico" aria-hidden>🛡️</span><span><T th="ผู้ดูแลระบบ (Admin)" en="Platform admin" zh="平台管理" /></span></Link>}
          <p className="truncate px-1 text-xs text-ink/50" title={user.email ?? ''}>{user.email}</p>
          <form action={signOut} className="mt-2">
            <button type="submit" className="navbtn logout"><span className="ico" aria-hidden>🚪</span><span><T th="ออกจากระบบ" en="Log out" zh="退出登录" /></span></button>
          </form>
        </div>
      </aside>
      <div className="min-w-0 flex-1"><BillingBanner sb={sb} tenantId={tenant.id} plan={tp?.plan_id ?? 'free'} />{children}
        <Copyright className="mt-12 border-t border-ink/10 pt-4 text-center text-xs text-ink/50" /></div>
    </div></div>
  )
}
